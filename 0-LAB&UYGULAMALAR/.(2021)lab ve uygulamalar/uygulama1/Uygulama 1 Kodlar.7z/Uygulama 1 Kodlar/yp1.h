#ifndef yp1
#define yp1

int topla(int x, int y);
int cikar(int x, int y);
int carp(int x, int y);
int bol(int x, int y);
int faktoriyel(int x);	
#endif 
