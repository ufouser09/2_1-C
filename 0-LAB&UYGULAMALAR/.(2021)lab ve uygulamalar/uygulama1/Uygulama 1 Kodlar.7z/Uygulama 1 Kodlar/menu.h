#ifndef MENU_H_
#define MENU_H_

#define MENU \
	printf("Toplama yapmak icin 1, \n");\
	printf("Cikarma yapmak icin 2, \n");\
	printf("Carpma icin 3, \n");\
	printf("Bolme icin 4, \n");\
	printf("Faktoriyel icin 5, \n");\
	printf("Cikis yapmak icin 6'ya basisiniz...\n");\

	
#endif // MENU_H_
