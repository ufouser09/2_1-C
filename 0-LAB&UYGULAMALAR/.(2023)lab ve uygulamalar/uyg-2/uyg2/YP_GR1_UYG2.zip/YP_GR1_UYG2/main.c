#include<stdio.h>
#include<stdlib.h>
#define NROW 16
#define NCOLUMN 2

/* uygulama-2
dinamik bellek y�netimi- tahsisi
malloc(), calloc(), free() 
*/

float** initialize_mat(int nrow, int ncolumn){
	int i;
	float **mat;
	mat = (float**)malloc(nrow*sizeof(float*));
	if(mat==NULL){
		printf("bellek ayr�lamad�.\n");
		exit(-1);
	}
	for(i=0;i<nrow;i++){
		mat[i]=(float*)calloc(ncolumn,sizeof(float));
		mat[i][0]=i+3;
	}
	return mat;
}

void calculate_prob(float **mat){
	int i, j, k, top;
	for(i=1;i<=6;i++){
		for(j=1;j<=6;j++){
			for(k=1;k<=6;k++){
				top=i+j+k;
				mat[top-3][1] += (float)1/(6*6*6);
			}
		}
	}
}

void print_prob(float **mat, int nrow){
	int i;
	printf("Toplam 		olasilik degeri:\n");
	for(i=0;i<nrow;i++){
		printf("%f\t%f\n",mat[i][0],mat[i][1]);
	}
}

void free_mat(float **mat, int nrow){
	int i;
	for(i=0;i<nrow;i++){
		free(mat[i]);
	}
	free(mat);
}

int main(){
	float **mat;
	int nrow=NROW, ncolumn=NCOLUMN;
	mat=initialize_mat(nrow,ncolumn);
	calculate_prob(mat);
	print_prob(mat,nrow);
	free_mat(mat,nrow);
	//print_prob(mat,nrow);
	return 0;
}
