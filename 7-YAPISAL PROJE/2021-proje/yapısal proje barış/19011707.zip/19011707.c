#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#define _GNU_SOURCE
#define OPEN_STATUS OPEN
#define CLOSED_STATUS CLOSED
#define RECORD_STATUS RECORDED


typedef struct Student{
  char name[20];
  
  int id;
  
  char surname[20];
  
  int total_enrolled_course;
  int total_course_credit;

  struct Student *next_student;
  struct Student *prev_student;

} STUDENT;

typedef struct Course{
  char id[7];
  int credit;
  char name[20];
  int capacity;
  int total_enrolled_students;
  int remain_capacity;
  int* enrolled_students;
  struct Course *next_course;

} COURSE;

typedef struct StudentClassRecord{

  int id;//auto increment
  char class_id[7];
  int student_number;
  char date[10];
  char status[20];

} STDCLASSRECORD;


void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
}
void selection_sort(int array[], int size) {
  int step;
  for (step = 0; step < size - 1; step++) {
    int min_idx = step;
    int i;
    for (i= step + 1; i < size; i++) {

      
      if (array[i] < array[min_idx])
        min_idx = i;
    }

    
    swap(&array[min_idx], &array[step]);
  }
}

STDCLASSRECORD* get_enrollments(int* count){
	FILE *fp;
	fp=fopen("ogrenciderskayit.txt","r");
	if(fp!=NULL){
		int id=0;
		char course_id[7];
		int std_id=0;
		char date[10];
		char status[20];
		
		STDCLASSRECORD* record=NULL;
		record=(STDCLASSRECORD*)malloc(sizeof(STDCLASSRECORD));
		while(fscanf(fp,"%d %s %d %s %s\n",&id,course_id,&std_id,date,status)==5){
			
			record=(STDCLASSRECORD*)realloc(record,id*sizeof(STDCLASSRECORD));
			
			record[id-1].id=id;
			
			strcpy_s(record[id-1].class_id,8,course_id);
			
			record[id-1].student_number=std_id;
			
			strcpy_s(record[id-1].date,10,date);
			
			strcpy_s(record[id-1].status,20,status);
			
		}
		
		*count=id;
		fclose(fp);	
		return record;
		
	}else{
		printf("Error:get_enrollments() -ogrenciderskayit.txt Couldnt be Opened ");
		return NULL;
	}
	
}

//return 1 if exist
int student_exist(STUDENT *head,STUDENT *new_student){
	STUDENT *current = head;
	while(current!=NULL){
		
		if(current->id==new_student->id){
			return 1;
		}
		current=current->next_student;
	}
	
	return 0;
}

//return 1 if exist
int course_exist(COURSE *head, COURSE *new_course){
  COURSE *current = head;
  
  while (current != NULL){

    if (strcmp(current->id, new_course->id)==0){
      //printf("\n Error:Course Exist \n");
      return 1;
    }
	
    current = current->next_course;
  }

  return 0;
}
//return 0 if successfull else 1
int add_course(COURSE **head, COURSE *new_course){
  if (*head == NULL){

    *head = new_course;
    printf("\n Log:Add new course to head \n");
    return 0;
  }else{
	int step=0;
    if (course_exist(*head, new_course)){
      printf("\n Var olan kursu ekleyemezsiniz!! \n");
      return 1;
    }else{
      COURSE *current;
      COURSE *next;

      current = *head;
      next = current->next_course;

      while (current != NULL && next != NULL){

        if (strcmp(next->id, new_course->id) > 0 && strcmp(current->id, new_course->id) < 0){
          current->next_course = new_course;
          new_course->next_course = next;
          return 0;
        }

        current = next;
        next = next->next_course;
      }

      if (next == NULL){
        if (strcmp(current->id, new_course->id) < 0){
          current->next_course = new_course;
          printf("\n Yeni ders listenin sonuna eklendi  \n");
        }else{

          COURSE *tmp = *head;
          *head = new_course;
          new_course->next_course = tmp;

          printf("\n Yeni ders listenin basina eklendi \n");
        }
      }

      //printf("\n Yeni kurs listeye eklendi\n");

      return 0;
    }
  }
}

COURSE* find_course(COURSE **head, char course_id[7]){

  COURSE *current = *head;

  while (current!= NULL){
  	
    if (strcmp(current->id,course_id)==0){
      //printf("\n Log:Course Found \n");
      return current;
    }

    current = current->next_course;
  }
  //printf("\n Log:Course Not Found \n");
  return NULL;
}

COURSE* create_course(char id[7], char name[20], int credit, int capacity){
  COURSE *new_course = (COURSE *)malloc(sizeof(COURSE));

  if (new_course == NULL){
  	
    printf("Error:Couldn't create a new course");
    
    return NULL;
  }

  strcpy_s(new_course->id, 8, id);

  strcpy_s(new_course->name, 20, name);

  new_course->credit = credit;
  new_course->capacity = capacity;
  new_course->remain_capacity = capacity;
  new_course->total_enrolled_students = 0;
  new_course->next_course = NULL;
  printf("\n creat_course():Yeni ders basarili bir sekilde olusturuldu\n");
  return new_course;
}
//remove 0 if successful
int remove_course(COURSE **head, COURSE *course){
  COURSE *current;
  COURSE *prev=NULL;
  current=*head;
  int is_found=0;
  while(current!=NULL && !is_found){
  	
  	if(strcmp(current->id,course->id)==0){
  		is_found=1;
  		if(prev==NULL){
  			*head=current->next_course;
		}else{
			prev->next_course=current->next_course;  	
		}
		
		free(current);
		printf("\n Ders basarili bir sekilde silindi\n");
	  }
	prev=current;
	current=current->next_course;
	  
  }
  return 0;
  
}

STUDENT* find_student(STUDENT **head,int student_id){
	
	STUDENT* current=*head;
	
	while(current!=NULL){
		if(current->id==student_id){
			//printf("\n find_student():Student Found \n");
			return current;
		}
		
		current=current->next_student;
	}
	//printf("\n find_student():Student Not Found \n");
	return NULL;
}

int remove_student(STUDENT **head,STUDENT *student){
	STUDENT *current=*head;
	STUDENT *prev=NULL;
	
	int is_found=0;
	while(current!=NULL && !is_found){
		if(current->id==student->id){
			
			is_found=1;
			if(prev==NULL){
				*head=student->next_student;
			}else{
				STUDENT* tmp=student->next_student;
				prev->next_student=student->next_student;
				tmp->prev_student=prev;
			}
			
			free(current);
			
		}else{
			
			prev=current;
			current=current->next_student;
		}
	}
	
	return 0;
}

STUDENT* create_student(char name[20], char surname[20], int id){
  STUDENT *new_student = (STUDENT*)malloc(sizeof(STUDENT));
  
  strcpy_s(new_student->name, 20, name);
  
  new_student->id = id;
  
  strcpy_s(new_student->surname, 20, surname);
  
  new_student->total_course_credit=0;
  new_student->total_enrolled_course=0;
  
  new_student->next_student=NULL;
  new_student->prev_student=NULL;
  
  
  return new_student;
}
//return 0 if successful
int add_student(STUDENT **head,STUDENT *student){
  if(*head==NULL){
  	*head=student;
  	printf("\n Yeni ogrenci listenin basina eklendi \n");
    return 0;
  }else{
  	if(student_exist(*head,student)){
  		
  		printf("\n Var olan ogrenci tekrar eklenemez\n");
  		
  		return 1;
  		
	}else{
		  	
	
  	
  	  STUDENT *current;
      STUDENT *next;
	  STUDENT *prev;
		
      current = *head;
      next = current->next_student;
	  prev = current->prev_student;
	  
	  
      while (current != NULL && next!=NULL){

        if (student->id > current->id && student->id < next->id){
        	
          current->next_student = student;
          student->prev_student=current;
          
          student->next_student = next;
          next->prev_student=student;
          
          return 0;
          
        }

        current = next;
        next = next->next_student;
      }

      if (next == NULL){
        if (current->id < student->id){
          
		  current->next_student = student;
		  student->prev_student=current;
		  
		  printf("\n Yeni ogrenci listenin sonuna eklendi \n");
		  return 0;
        }else{

          STUDENT *tmp = *head;
          *head = student;
          student->next_student = tmp;
          printf("\n Yeni ogrenci listenin basina eklendi \n");
          return 0;
        }
      }

      //printf("\n Log:add new student to list\n");

      return 0;
      
    }  
  }
  return 0;
}

STUDENT* get_students(){
	FILE *fp;
	fp=fopen("ogrenciler.txt","r");
	if(fp==NULL){
		fclose(fp);
		return NULL;
	}
	STUDENT *head=NULL;
	STUDENT *prev=NULL;
	STUDENT *current=NULL;
	
	
	
	int id,total_credit,total_lesson;
	char name[20],surname[20];
		
	while(fscanf(fp,"%d %s %s %d %d\n",&id,name,surname,&total_lesson,&total_credit)==5){
		current=(STUDENT*)malloc(sizeof(STUDENT));	
		
		
		current->id=id;
		
		
		strcpy_s(current->name,20,name);
		
		
		strcpy_s(current->surname,20,surname);
		
		
		current->total_enrolled_course=total_lesson;
		
		
		current->total_course_credit=total_credit;
		
		current->next_student=NULL;
		current->prev_student=NULL;
		
		if(head==NULL){
			head=current;
			head->next_student=NULL;
			head->prev_student=NULL;
			prev=head;
		}else{	
			
			prev->next_student=current;
			current->prev_student=prev;
			prev=current;
			current=NULL;
		}	
	}
	fclose(fp);
	return head;
}

//return 0 if successfu�
int save_students(STUDENT* head){
	
	FILE *fp;
	fp=fopen("ogrenciler.txt","w");
	
	if(fp==NULL){
		printf("\n save_student(): ogrenciler.txt couldn't open \n");
		fclose(fp);
		return 1;
	}
	
	STUDENT *current=head;
	
	//Format
	//Id,Name,Surname,Enrolled Classes,Total Credit
	while(current!=NULL){
		
		fprintf(
		fp,
		"%d %s %s %d %d\n",
		current->id,
		current->name,
		current->surname,
		current->total_enrolled_course,
		current->total_course_credit
		);
		current=current->next_student;
		
	}
	fclose(fp);
	printf("\n ogrenciler.txt dosyasi kaydedildi \n");
	return 0;
}

COURSE* get_courses(){
	FILE *fp;
	
	fp=fopen("dersler.txt","r");
	if(fp==NULL){
		fclose(fp);
		return NULL;
	}
	
	COURSE *head=NULL;
	COURSE *prev=NULL;
	COURSE *current=NULL;
	
	
	
	int credit,capacity;
	char name[20],id[7];
	
	
	while(fscanf(fp,"%s %s %d %d\n",id,name,&credit,&capacity)==4){
		current=(COURSE*)malloc(sizeof(COURSE));	
		
		
		strcpy_s(current->id,8,id);
		strcpy_s(current->name,20,name);
		current->total_enrolled_students=0;
		current->enrolled_students=NULL;
		current->credit=credit;
		current->capacity=capacity;
		current->next_course=NULL;
		
		if(head==NULL){
			head=current;
			head->next_course=NULL;
			prev=head;
			
		}else{
			prev->next_course=current;
			prev=current;
			current=NULL;
		}
	}
	
	return head;
}

int save_courses(COURSE* head){
	FILE *fp;
	fp=fopen("dersler.txt","w");
	
	if(fp==NULL){
		//printf("\n save_course(): dersler.txt couldn't open \n");
		fclose(fp);
		return 1;
	}
	
	COURSE *current=head;
	
	//Format
	//Id,Name,Credit,Capacity
	while(current!=NULL){
		
		fprintf(
		fp,
		"%s %s %d %d\n",
		current->id,
		current->name,
		current->credit,
		current->capacity
		);
		current=current->next_course;
		
	}
	fclose(fp);
	//printf("\n save_course(): dersler.txt saved successfully \n");
	return 0;
}

void print_student(STUDENT* head){
  STUDENT *tmp = head;
  while(tmp != NULL){
    printf("\n%d, %s, %s \n",tmp->id,tmp->name,tmp->surname);
    tmp = tmp->next_student;
    
  }	
  //free(head);
  
}

void print_course(COURSE *head){
	
  COURSE *current = head;
  
  while (current != NULL){
    printf("\n %s, %s, %d, %d \n", current->id, current->name, current->credit, current->capacity);
    current = current->next_course;
  }
}

void fill_course(COURSE* course){
	int count=0;
	STDCLASSRECORD* records=get_enrollments(&count);
	COURSE* current_course=course;
	
	
	int i;
	for(i=0;i<count;i++){
		if(strcmp(current_course->id,records[i].class_id)==0 && strcmp(records[i].status,"kayitli")==0){
			
			if(current_course->enrolled_students==NULL){
				current_course->enrolled_students=(int*)malloc(sizeof(int));
				current_course->total_enrolled_students=1;
				current_course->enrolled_students[0]=records[i].student_number;
			}else{
				current_course->total_enrolled_students++;
				current_course->enrolled_students=(int*)realloc(current_course->enrolled_students,current_course->total_enrolled_students*sizeof(int));		
				current_course->enrolled_students[current_course->total_enrolled_students-1]=records[i].student_number;
			}
			current_course->capacity--;
		}
	}
	selection_sort(current_course->enrolled_students,current_course->total_enrolled_students);
		
}

void fill_student(STUDENT* student){
	int count=0;
	STDCLASSRECORD* records=get_enrollments(&count);
	COURSE* courses=get_courses();
	int i=0;
	for(;i<count;i++){
		if(student->id==records[i].student_number && strcmp(records[i].status,"kayitli")==0){
			COURSE* crs=find_course(&courses,records[i].class_id);
			int credit=crs->credit;
			student->total_course_credit+=credit;
			student->total_enrolled_course++;
		}
	}
}

int enroll_student(STDCLASSRECORD* records,int newsize,COURSE* course,STUDENT* student,char date[10]){
	records=(STDCLASSRECORD*)realloc(records,newsize*sizeof(STDCLASSRECORD));
	strcpy_s(records[newsize-1].status,8,"kayitli");
	records[newsize-1].id=newsize;
	strcpy_s(records[newsize-1].class_id,8,course->id);
	records[newsize-1].student_number=student->id;
	strcpy_s(records[newsize-1].date,11,date);	
}

//return 1 if takes
int std_take_course(COURSE* course,STUDENT* student){
	int i;
	for(i=0;i<course->total_enrolled_students;i++){
		if(course->enrolled_students[i]==student->id){
			return 1;
		}
	}
	
	return 0;
}


//return 0 if success
int save_enrollments(STDCLASSRECORD* head,int size){
	FILE *fp;
	fp=fopen("ogrenciderskayit.txt","w");
	
	if(fp!=NULL){
		if(head!=NULL){
			int n;
			STDCLASSRECORD* current=head;
			for(n=0;n<size;n++){
				fprintf(fp,"%d %s %d %s %s\n",current[n].id,current[n].class_id,current[n].student_number,current[n].date,current[n].status);
			}
			fclose(fp);
			printf("\n save_enrollments(): ogrenciderskayit.txt saved successfully\n");
			return 0;
		}	
		printf("\n save_enrollments(): head NULL\n");
		return 1;
	}else{
		printf("Error:save_enrollments() -ogrenciderskayit.txt Couldnt be Opened ");
		return 1;
	}
	

}

STDCLASSRECORD* find_record(STDCLASSRECORD* records,int count,int std_id,char crs_id[7]){
	int i;
	for(i=0;i<count;i++){
		if(strcmp(records[i].class_id,crs_id)==0 && records[i].student_number==std_id){
			return &records[i];
		}
	}
	
	return NULL;
}

int print_enrolled_students(COURSE* course,STUDENT* students){
	FILE* fp;
	char *filename=course->id;
	char *ext=".txt";
	
	fp=fopen(strcat(filename,ext),"w");
	if(fp!=NULL){
		
		int i=0;
		for(;i<course->total_enrolled_students;i++){
			STUDENT* student=find_student(&students,course->enrolled_students[i]);
			fprintf(fp,"%d %s %s\n",student->id,student->name,student->surname);
			printf("%d %s %s\n",student->id,student->name,student->surname);
		}
		
		fclose(fp);
		return 0;
		
	}else{
		
		printf("print_enrolled_students():file couldn't opened");
		return 1;
	}
	
	
	
}

int print_enrolled_lessons(STUDENT* student,COURSE* courses,STDCLASSRECORD* records,int count){
	FILE* fp;
	if(student!=NULL){
		
	
	//19011707
	char str_id[8];
	sprintf(str_id,"%d",student->id);
	fp=fopen(strcat(str_id,"_DERSPROGRAMI.txt"),"w");
	if(fp!=NULL){
		int i=0;
		for(;i<count;i++){
			if(records[i].student_number==student->id && strcmp(records[i].status,"kayitli")==0){
				COURSE* course=find_course(&courses,records[i].class_id);
				fprintf(fp,"%s %s %d\n",course->id,course->name,course->credit);
				printf("%s %s %d\n",course->id,course->name,course->credit);
			}
		}
		
		fclose(fp);
		
		return 0;
	}else{
		
		return 1;
	}
	}else{
		return 1;
	}
}

void close_course(COURSE* course){
	int count=0;
	STDCLASSRECORD* enrollments=get_enrollments(&count);
	int i=0;
	for(;i<count;i++){
		if(strcmp(enrollments[i].class_id,course->id)==0){
			strcpy_s(enrollments[i].status,8,"kapandi");
		}
	}
	
	save_enrollments(enrollments,count);
}

void reopen_course(COURSE* course){
	int count=0;
	STDCLASSRECORD* enrollments=get_enrollments(&count);
	int i=0;
	for(;i<count;i++){
		if( strcmp(course->id,enrollments[i].class_id)==0 && strcmp(enrollments[i].status,"kapandi")==0){
			strcpy_s(enrollments[i].status,8,"kayitli");
		}
	}
	
	save_enrollments(enrollments,count);
}

void free_courses(COURSE* course){
	COURSE* tmp=NULL;
	while(course!=NULL){
		tmp=course;
		course=course->next_course;
		free(tmp);
	}
}

void free_students(STUDENT* student){
	STUDENT* tmp;
	while(student!=NULL){
		tmp=student;
		student=student->next_student;
		free(tmp);
	}
}

void free_records(STDCLASSRECORD* record){
	
	free(record);
}
int main(){

  //COURSE *courses = NULL;
  //STUDENT *students = NULL;
  int max_credit=0;
  int max_lesson=0;
  
  printf("\nMax Kredi Giriniz:");
  scanf("%d",&max_credit);
  
  printf("\nMax Ders Giriniz:");
  scanf("%d",&max_lesson);
  printf("\n");
  
  int exit = 0;
  while (!exit){

    int option;
    printf(
        " Yapmak Istediginiz Islemi Seciniz \n"
        "DERSLER \n"
        
		"1-Dersleri Listele \n"
        "2-Yeni Ders Ekle \n"
        "3-Ders Sil-Kapa \n"
        
        "OGRENCILER \n"
        
        "4-Ogrencileri Listele \n"
        "5-Yeni Ogrenci Ekle \n"
        "6-Ogrenci Sil \n"
        
        "KAYITLAR \n"
        
		"7-Derse Ogrenci Kaydet \n"
		"8-Dersten Ogrenci Cikar(Birak)  \n"
		
		"KOMUTLAR \n"
		"9-Derse Kayitli Ogrencileri Yazdir\n"
		"10-Ogrencinin Kayitli Oldugu Dersleri Yazdir \n"
		
		);

    scanf("%d", &option);
	int count=0;
	
    if (option == 1){
    	
    	COURSE* crs=get_courses();
		print_course(crs);
      	free_courses(crs);
    }
	else if (option == 2){

      char course_name[20], course_id[7];
      int capacity, credit;

      printf("\n Ders Id giriniz(Max 7 Char):");
      scanf("%s", course_id);

      printf("\n Ders Adi giriniz (Max 20 Characters):");
      scanf("%s", course_name);

      printf("\n Ders Kapasite giriniz:");
      scanf("%d", &capacity);

      printf("\n Ders kredi giriniz:");
      scanf("%d", &credit);

      COURSE *new_course = create_course(course_id, course_name, credit, capacity);
      if (new_course == NULL){
      	
        printf("\n Error:new_course is null\n");
        
      }else{
      	
      	COURSE* crs=get_courses();
      	
      	if(add_course(&crs, new_course)==0){
      		
      		//if course exist in records rename it to kayitli
      		
      		save_courses(crs);	
      		
      		reopen_course(crs);
	  	}	
	  	
		free_courses(crs);
	  	
	  }
	  
	  
	      
    }
    else if (option == 3){
      //remove a course
      char course_id[7];
      printf("\n Kaldirilacak olan dersin Id giriniz (Max 7 Char):");
      scanf("%s", course_id);
      COURSE* crs=get_courses();
      COURSE *course = find_course(&crs, course_id);

      if (course != NULL){
        
        if(remove_course(&crs, course)==0){
        	save_courses(crs);
        	close_course(course);
		}
		
      }else{
      	printf("\n Silinecek Ders bulunamadi \n");
	  }
      
      free_courses(crs);
    }
	else if (option == 4){
    	
    	STUDENT* std =get_students();
        print_student(std);
    	
    	free_students(std);
    	
    }
	else if (option == 5){
    	//add student
    	char name[20],surname[20];
      	int id;

      	printf("\n Ogrenci No giriniz(Number):");
      	scanf("%d", &id);

      	printf("\n Ogrenci Adi giriniz (Max 20 Char):");
      	scanf("%s", name);

      	printf("\n Ogrenci Soyadi giriniz:");
      	scanf("%s", surname);

      	STUDENT* new_student = create_student(name, surname,id);
      	if (new_student == NULL){
        	printf("\n Yeni ogrenci NULL \n");
      	}
		STUDENT* std=get_students();
      	if(add_student(&std, new_student)){
        	
			printf("\n Yeni ogrenci eklenemedi \n");
        	
	    }else{
	    	
	    	save_students(std);	
	    	
		}
		free_students(std);
    	
    }
	else if (option == 6){
    	//remove student
    	int id;
      	printf("\n Silinecek Ogrencinin No giriniz (Number):");
      	scanf("%d",&id);
      	
      	STUDENT *std=get_students();
      	STUDENT *student = find_student(&std,id);

      	if (student != NULL){
      		
        	if(remove_student(&std, student)){
        		printf("\n Ogrenci kaldirilamadi \n");
			}else{
				save_students(std);	
				printf("\n Ogrenci kaldirildi\n");
			}
        	
        	
      	}else{
      		printf("\n Ogrenci bulunamadi \n");
		}
		
		free_students(std);
    	
    }
	else if(option==7){
    	//Get Student Id -> Check is exist
    	//Get Course ID -> Check is exist
    	//if yes,
    	//get enrollements record pointer
    	//add it to last
    	//
    	int std_id;
    	printf("\nOgrenci No Giriniz:");
    	scanf("%d",&std_id);
    	char crs_id[7];
    	printf("\nDers Id Giriniz:");
    	scanf("%s",crs_id);
    	
		char date[10];
    	printf("\nTarih giriniz(gg.AA.yyyy):");
    	scanf("%s",date);
    	
    	COURSE* courses=get_courses();
    	COURSE* crs=find_course(&courses,crs_id);
    	if(crs!=NULL){
    		STUDENT* students=get_students();
    		STUDENT* std=find_student(&students,std_id);
    		
    		if(std!=NULL){
    			//fill_student(std);//fill student with its credits and lessons	
    			fill_course(crs);//fill course wiht its students
    			
    			if(!std_take_course(crs,std) && (crs->capacity>0) && (std->total_course_credit+crs->credit<=max_credit)){ 
    				//
    				int size=0;
    				STDCLASSRECORD* records=get_enrollments(&size);
    				STDCLASSRECORD* record=find_record(records,size,std->id,crs->id);
    				
    				if(record!=NULL)
					{
    					if(strcmp(record->status,"birakti")==0)
						{
    						
							std->total_course_credit+=crs->credit;
    						std->total_enrolled_course++;
    						
    						strcpy_s(record->status,8,"kayitli");
    						save_students(students);
    						save_enrollments(records,size);	
    						
						}
						else if(strcmp(record->status,"kapandi")==0){
							printf("\n Kapali derse ogrenci katilamaz \n");
						}
						else if(strcmp(record->status,"kayitli")==0){
							printf("\n Ogrenci kayitli oldugu derse tekrar katilamaz\n");
						}
    					
					}
					else{
						
						enroll_student(records,size+1,crs,std,date);
						
						std->total_course_credit+=crs->credit;
    					std->total_enrolled_course++;
    						
    					save_students(students);
    					save_enrollments(records,size+1);	
					}
    				
    				free_records(records);
    				//
					//if student doesnt take lesson and have capacity enroll it
					//
					//enroll student
				}
				else{
					
					if(std_take_course(crs,std)){
						printf("\n Ogrenci ayni ders tekrar alamaz \n");
					}else if(!(crs->capacity>0)){
						printf("\n Ders Kapasitesi dolu \n");
					}else if(std->total_course_credit+crs->credit>max_credit){
						printf("\n Ogrenci yeteri kadar krediye sahip degil \n");
					}
				}
			}else{
				printf("\n Ogrenci bulunamadi \n");
			}
			
			free_students(students);
			
		}else{
			printf("\n Ders bulunamadi \n");
		}
		
		free(courses);
	}
	else if(option==8){
		int std_id;
    	printf("\nOgrenci No Giriniz:");
    	scanf("%d",&std_id);
    	char crs_id[7];
    	printf("\nDers Id Giriniz:");
    	scanf("%s",crs_id);
    	
		char date[10];
    	printf("\nTarih giriniz(gg.AA.yyyy):");
    	scanf("%s",date);
		
		COURSE* courses= get_courses();
		COURSE* crs=find_course(&courses,crs_id);
		STUDENT* students= get_students();
		STUDENT* std=find_student(&students,std_id);
		
		int size=0;
    	STDCLASSRECORD* records=get_enrollments(&size);
    	int i=0;
    	for(;i<size;i++){
    		if(strcmp(records[i].class_id,crs_id)==0 && records[i].student_number==std_id){
    			if(strcmp(records[i].status,"kayitli")==0){
    				strcpy_s(records[i].status,8,"birakti");
    				printf("\n Ders ba�ar�l� bir �ekilde birakildi.\n");
				}
				else if(strcmp(records[i].status,"kapandi")==0){
					printf("\n Kapali olan ders birakilamaz\n")	;
				}
				else if(strcmp(records[i].status,"birakti")==0){
					printf("\n Birakilan ders tekrar birakilamaz\n")	;
				}
			}
		}
		
		std->total_course_credit-=crs->credit;
		std->total_enrolled_course-=1;
		
		save_enrollments(records,size);
		save_students(students);
		//
		//remove a student from list
		//
		free_records(records);
		free_courses(courses);
		free_students(students);
	}
	else if(option==9){
		char course_id[7];
		printf("Dersi alan ogrencileri listelemek icin ders kodu giriniz:");
		scanf("%s",course_id);
		COURSE* courses= get_courses();
		STUDENT* students=get_students();
		COURSE* course= find_course(&courses,course_id);
		if(course!=NULL){
			fill_course(course);
		
		 	if(print_enrolled_students(course,students)==0){
		 		printf("\n %s Dersine Kayitli ogrenciler yazdirildi \n",course->id);
		 	}else{
		 		printf("\n %s Dersine kayitli ogrenciler yazdirilamadi \n",course->id);
		 	}
			
		}else{
			printf("\n Olmayan dersi kay�tlari listelenemez\n");
		}
		 
		 free_courses(courses);
		 free_students(students);
	}
	else if(option==10){
		//
		int student_id=0;
		printf("\n Ogrencinin derslerini listelemek icn ogrenci No giriniz:");
		scanf("%d",&student_id);
		STUDENT* students=get_students();
		STUDENT* student=find_student(&students,student_id);
		if(student!=NULL){
			
		
			COURSE* courses=get_courses();
			int count;
			STDCLASSRECORD* records=get_enrollments(&count);
			if(print_enrolled_lessons(student,courses,records,count)==0){
				printf("\n %d Numarali ogrencinin kayitli oldugu dersler yazdirildi \n",student->id);		
			}else{
				printf("\n %d Numarali ogrencinin kayitli oldugu dersler yazdirilamadi \n",student->id);		
			}
			
			free_records(records);
			free_courses(courses);
		}else{
			printf("\nOlmayan ogrecinin dersleri yazdirilamaz\n");
		}
		
		
		free_students(students);
		
	}

    printf("\n Cikmak istiyor musunuz?:Evet(1) Hayir(0)");
    scanf("%d", &exit);
  }
  
  return 0;
}

