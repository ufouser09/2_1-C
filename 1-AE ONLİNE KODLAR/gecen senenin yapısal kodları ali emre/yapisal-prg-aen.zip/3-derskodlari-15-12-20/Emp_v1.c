#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Employee{
	char name[21];
	char surname[21];
	char id[11];
	struct Employee *next;
}EMPLOYEE;

EMPLOYEE *createNode();
void addRecord(EMPLOYEE **phead);
void removeRecord(EMPLOYEE **phead);
void printRecords(EMPLOYEE*head, void (*fptr)(EMPLOYEE *));
void printfNameFirst(EMPLOYEE *emp);
void printfIdFirst(EMPLOYEE *emp);

int main(){
	EMPLOYEE *head=NULL;
	int choice=0;
	while(choice!=3){
		printf("1-Add \n2-Remove\n3-Exit");
		scanf("%d",&choice);
		switch(choice){
			case 1: addRecord(&head); printRecords(head,printfIdFirst);break;
			case 2: removeRecord(&head); printRecords(head,printfNameFirst);break;
		}
	}
}

EMPLOYEE *createNode(){
	EMPLOYEE *emp;
	emp = (EMPLOYEE*) malloc(sizeof(EMPLOYEE));
	printf("Enter id, name and surname, respectively");
	scanf("%s %s %s",&emp->id,&emp->name,&emp->surname);
	printf("Eleman olu�turuldu");
	return emp;
}

void addRecord(EMPLOYEE **phead){
	EMPLOYEE *emp=createNode();
	emp->next=*phead;
	*phead=emp;
}

void removeRecord(EMPLOYEE **phead){
	char id[11];
	EMPLOYEE *current=*phead;
	EMPLOYEE *prev=NULL;
	int found=0;
	printf("Enter id of the employee to be remove");
	scanf("%s",id);
	while(current!=NULL && !found){
		if(strcmp(current->id,id)==0){
			found=1;
			if(prev==NULL){
				*phead=current->next;
			}
			else{
				prev->next=current->next;
			}
			free(current);
		}
		else{
			prev=current;
			current=current->next;
		}	
	}	
}
void printRecords(EMPLOYEE*head, void (*fptr)(EMPLOYEE *)){
	EMPLOYEE *tmp=head;
	while(tmp!=NULL){
		fptr(tmp);
		tmp=tmp->next;
	}
}

void printfNameFirst(EMPLOYEE *emp){
	printf("%s %s %s\n",emp->name,emp->id,emp->surname);
}
void printfIdFirst(EMPLOYEE *emp){
	printf("%s %s %s\n",emp->id,emp->name,emp->surname);
}
