#include <stdio.h>
#include <stdlib.h>

int main(){
	FILE *fp;
	//int fpos;
	fpos_t pos;
	char dizi[11];
	if((fp=fopen("dosya.txt","w+"))==NULL){
		printf("hata");
		return;
	}
	fputs("Bilgisayar\n",stdout);//dikkat
	fputs("Bilgisayar",fp);
	fseek(fp,0,SEEK_SET); //rewind(fp)
	fgetpos(fp,&pos);
	printf("Dosyanin aktif konumu:%ld",pos);
	fgets(dizi,11,fp);
	printf("\nokunan veri:%s\n",dizi);
	fgetpos(fp,&pos);
	printf("Dosyanin aktif konumu:%ld\n",pos);
	fseek(fp,-5,SEEK_CUR);
	fgetpos(fp,&pos);
	fputs("xxxxxxxxxxxx",fp);
	printf("Dosyanin aktif konumu:%ld\n",pos);
	fgets(dizi,11,fp);
	printf("\nokunan veri:%s\n",dizi);
	fclose(fp);
}
