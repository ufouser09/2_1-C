// Bir okulda ogrencilerin isim, numara ve puan bilgileri structure'da tutulmaktadir
// Kullan�c� ��renci say�s�n� ve bu ��rencilerin bilgilerini numaralar�na 
//g�re k���kten b�y��e s�ral� olacak �ekilde verdi�inde bu bilgileri 
// blok blok bir binary dosyaya yazan fonksiyonu yaz�n�z
// Kullan�c�n�n verdi�i bir ��renci numaras�n� olu�turulan dosyada 
// ana fonksiyonu yaz�n�z. arayarak bulmas� halinde  ilgili ��rencinin bilgilerini ekrana yazd�ran 
// Ornek �al��ma a�a��daki gibidir:
/*
Olusturulacak dosyanin ismini veriniz
ogrenci.bin
kac ogrenci var
3
bilgilerini veriniz
ali 123 90
veli 134 80
hasan 180 79
aradiginiz ogrenci numarasi?
134
ilgili kisinin bilgileri:
veli 134 80
*/
#include <stdio.h>
#include <stdlib.h>
#define MAX 20

typedef struct ogr{
	char ad[MAX];
	int no;
	int puan;
}OGR;

int main(){
	char dosya[20];
	FILE* fp;
	int no;
	OGR ogr;
	printf("Dosya adi giriniz"); scanf("%s",dosya);
	print_file(dosya);
	fp=fopen(dosya,"rb");
	if(fp!=NULL){
		printf("Ogr No:"); scanf("%d",&no);
	}
	fread(&ogr,sizeof(OGR),1,fp);
	while((ogr.no<no) && (!(feof(fp)))){
		fread(&ogr,sizeof(OGR),1,fp);
	}
	if(ogr.no==no){
		printf("Bulunan Bilgiler\n");
		printf("%s %d %d\n",ogr.ad,ogr.no,ogr.puan);
	}
	else{
		printf("Kayit bulunamadi");
	}
	return 0;
}

void print_file(char ad[20]){
	int N;
	int i;
	OGR e;
	FILE *fp=fopen(ad,"wb");
	printf("Ogrenci Sayisi"); scanf("%d",&N);
	printf("Bilgiler(isim-numara-puan)\n");
	for(i=0;i<N;i++){
		fscanf(stdin,"%s %d %d",e.ad,&e.no,&e.puan);
		fwrite(&e,sizeof(OGR),1,fp);
	}
	fclose(fp);
}

