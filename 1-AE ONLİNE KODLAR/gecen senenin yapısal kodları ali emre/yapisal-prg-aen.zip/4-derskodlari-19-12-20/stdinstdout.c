#include <stdio.h>
int main(void) {
 // variables
 int id, score;
 // take user input
 printf("Enter ID: ");
 fscanf(stdin, "%d", &id); //scanf("%d",&id);
 printf("Enter Score: ");
 fscanf(stdin, "%d", &score);
 // print output
 printf("\nDetail:\n");
 fprintf(stdout, "ID: %d\n", id);
 fprintf(stdout, "Score: %d\n", score);
 return 0;
}
