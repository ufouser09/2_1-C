#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Node{
	char name[15];
	int X;
	int Y;
	struct Node *next;
}NODE;
int asc(int a, int b);
int desc(int a, int b);
void swap(NODE *a, NODE *b);
int main(){
	FILE *fp;
	char name[15];
	int x,y;
	NODE *head=NULL;
	fp=fopen("input.txt","r+");
	if(fp!=NULL){
		printf("Dosya acildi");
		while(!feof(fp)){
			fscanf(fp,"%s %d %d",name,&x,&y);
			insert(&head,name,x,y);
		}
		bubleSort(head,asc);
		writetoFile(head,fp);
		fprintf(fp,"\n----------\n");
		bubleSort(head,desc);
		writetoFile(head,fp);
		fclose(fp);
		free(head);
	}
	else{
		printf("Dosya acilamadi");
	}	
}

void insert(NODE **ref, char *name, int x, int y){
	NODE *n=(NODE*) malloc(sizeof(NODE));
	strcpy(n->name,name);
	n->X=x;
	n->Y=y;
	n->next=*ref;
	*ref=n;
}

void bubleSort(NODE *head, int (*cmp)(int a,int b)){ //bubleSort(head,asc);
	int swapped, i, d1,d2;
	NODE *p1;
	NODE *lptr=NULL;
	if(head==NULL){
		return;
	}
	do{
		swapped=0;
		p1=head;
		while(p1->next!=lptr){
			d1=(int) pow(p1->X,2) + pow(p1->Y,2);
			d2=(int) pow(p1->next->X,2) + pow(p1->next->Y,2);
			if((*cmp)(d1,d2)){
				swap(p1,p1->next);
				swapped=1;
			}
			p1=p1->next;
		}
		lptr=p1;	
	}while(swapped);	
}
void swap(NODE *a, NODE *b){
	char ad[20];
	int tmp;
	tmp=a->X;
	a->X=b->X;
	b->X=tmp;
	tmp=a->Y;
	a->Y=b->Y;
	b->Y=tmp;
	//illegal-ad=a->name; 	a->name=b->name; 	b->name=ad;	
	strcpy(ad,a->name); //\0
	strcpy(a->name,b->name);
	strcpy(b->name,ad);	
}

int asc(int a, int b){
	return b<a;
}
int desc(int a, int b){
	return b>a;
}
void writetoFile(NODE *head, FILE *fp){
	int kare;
	NODE *tmp=head;
	while(tmp!=NULL){
		kare=pow(tmp->X,2)+pow(tmp->Y,2);
		fprintf(fp,"\n%s--%d--%d--%d",tmp->name,tmp->X,tmp->Y,kare);
		tmp =tmp->next;
	}	
}


  
