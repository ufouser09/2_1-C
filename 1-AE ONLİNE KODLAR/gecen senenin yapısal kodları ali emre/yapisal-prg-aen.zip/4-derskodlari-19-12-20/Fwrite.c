#include<stdio.h>
#include<conio.h>
void main()
{
struct emp
{
int eno;
char ename[20];
float sal;
}e,i,j;
FILE *fp;
fp=fopen("emp.dat", "wb");

printf("Enter employee number");
scanf("&d",&e.eno);
printf("Enter employee name");
fflush(stdin);
scanf("%s",e.ename); 
printf("Enter employee salary");
scanf("%f",&e.sal);
fwrite(&e,sizeof(e),4,fp);
printf("four records stored successfully");
fclose(fp);
fp=fopen("Emp.dat","rb");
fread(&i,sizeof(i),1,fp);
printf("\nEmployee number is %d",i.eno);
printf("\nEmployee name is %s",i.ename);
printf("\nEmployee salary is %f",i.sal);

fread(&j,sizeof(j),1,fp);
printf("\nEmployee number is %d",j.eno);
printf("\nEmployee name is %s",j.ename);
printf("\nEmployee salary is %f",j.sal);
printf("One record read successfully");
getch();
}
