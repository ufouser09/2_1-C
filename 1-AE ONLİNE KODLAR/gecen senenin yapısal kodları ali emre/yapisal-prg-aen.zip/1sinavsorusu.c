#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct{
	int id, age, grade;
	char name[20];
}STUDENT;
void liste_yaz(STUDENT*, int );
void nota_gore_sirala(STUDENT*, int );
void ada_gore_sirala(STUDENT*,int );
int main(){
	int N,i;
	STUDENT *std;
	printf("N degeri: "); scanf("%d",&N);
	
	std=(STUDENT*)calloc(N,sizeof(STUDENT));
	if(std!=NULL){
		for(i=0;i<N;i++){
			printf("%d. Ogrenci id",i); scanf("%d",&std[i].id);
			printf("%d. Ogrenci adi",i); scanf("%s",std[i].name);
			printf("%d. Ogrenci notu",i); scanf("%d",&std[i].grade);
			printf("%d. Ogrenci yasi",i); scanf("%d",&std[i].age);
		}
		liste_yaz(std,N);
		nota_gore_sirala(std,N);
		liste_yaz(std,N);
		ada_gore_sirala(std,N);
		liste_yaz(std,N);
		free(std);
	}
	else{
		printf("Error");
		return -1;
	}
	return 0;
}

void liste_yaz(STUDENT*dizi, int N){
	int i;
	printf("ID\tAD\tNOT\tYAS\n");
	for(i=0;i<N;i++){
		printf("%d\t%s\t%d\t%2.f\n",dizi[i].id,dizi[i].name,dizi[i].grade,dizi[i].age);
	}
}

void nota_gore_sirala(STUDENT*dizi, int N){
	int i,j;
	STUDENT t;
	for(i=0;i<N-1;i++){
		for(j=0;j<N-1;j++){
			if(dizi[j].grade<dizi[j+1].grade){
				t=dizi[j+1];
				dizi[j+1]=dizi[j];
				dizi[j]=t;
			}
		}	
	}
}

void ada_gore_sirala(STUDENT*dizi,int N){
	int i,j;
	STUDENT t;
	for(i=0;i<N-1;i++){
		for(j=0;j<N-1;j++){
			if(strcmp(dizi[j].name,dizi[j+1].name)==1){
				t=dizi[j+1];
				dizi[j+1]=dizi[j];
				dizi[j]=t;
			}
		}	
	}
}
