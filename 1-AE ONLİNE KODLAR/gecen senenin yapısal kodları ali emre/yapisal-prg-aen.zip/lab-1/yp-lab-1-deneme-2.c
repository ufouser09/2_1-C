#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
	int n, m, i, j, pixel, textIndex=0;
	char *text;
	int **image;
	
	printf("Enter image size: M ");
	scanf("%d", &m);
	
	text = (char*)malloc(sizeof(char));
	
	image = (int**)calloc(m, sizeof(int*));
	for(i=0 ; i<m ; i++){
		image[i] = (int*)calloc(m,sizeof(int));
	}
	
	printf("Enter the pixel values from top-left to bottom right\n");
	for(i=0 ; i<m ; i++){
		for(j=0 ; j<m ; j++){
			printf("(%d, %d) = ", i, j);
			scanf("%d", &pixel);
			image[i][j] = pixel;
		}
	}
	
	for(i=0 ; i<m ; i++){
		for(j=0 ; j<m ; j++){
			text = (char*)realloc(text,sizeof(char));
			text[textIndex] = (char)image[i][j];
			textIndex++;
		}
	}
	
	printf("Text is: %s", text);
	free(image);
	free(text);
	
	return 0;
}
