#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define SIZE 200;

int main(){
	int textSize, m, i, j, k=0, pixel;
	char *text, junk;
	int **image;
	
	printf("Enter the lenght of text: ");
	scanf("%d", &textSize);
	
	text = (char*)malloc(sizeof(char)*textSize);
	
	
	printf("Enter the text:\n");
	scanf("%c", &junk);
	scanf("%[^\n]", text);
	
	m = ceil(sqrt(textSize));
	//"ceil" yuvarlamaya yar�yor.
	
	image = (int**)calloc(m,sizeof(int*));
	for(i=0 ; i<m ; i++){
		image[0] = (int*)calloc(m,sizeof(int));
	}
	
	for(i=0 ; i<m ; i++){
		image = (int**)realloc(image, (i+1)*sizeof(int*));
		for(j=0 ; j<m ; j++){
			image[i] = (int*)realloc(image[i], (j+1)*sizeof(int));
			if(k < textSize){
				pixel = (int)text[k];
				image[i][j] = pixel;
			}else{
				image[i][j] = 0;
			}
			k++;
		}
	}
	
	for(i=0 ; i<m ; i++){
		for(j=0 ; j<m ; j++){
			printf("%3d ", image[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
