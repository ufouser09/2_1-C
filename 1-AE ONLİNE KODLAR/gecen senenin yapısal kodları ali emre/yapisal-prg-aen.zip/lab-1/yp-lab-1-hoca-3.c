#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include<locale.h>

int main(int argc, char *argv[]) {
    // T�rk�e karakter kullanmak i�in kullan�l�r.
    setlocale(LC_ALL, "Turkish");

    // n kullan�c�dan al�nacak tam say�y� tutar.
    // i ve j de�erleri d�ng�lerde kullan�lmak �zere tan�mlan�r.
    // prime_count de�i�keni olu�turulan asal say�lar�n say�s�n�n tutulaca�� de�i�kendir.
    // primes dizisi tespit edilen asal say�lar�n tutulaca�� dizidir.
    int n, i, j, prime_count, *primes;
    
    // char veri tipinin uzunlu�u 1 byte'd�r. Minimum uzunluk oldu�u i�in true ve false de�erlerini saklamak i�in bu veri tipini kullnabiliriz. 
    // prime_states dizisi say�lar�n asal olup olmama durumunun tutulaca�� dizidir. Asal say� ise de�eri 1(true), de�il ise 0(false) de�eri dizide tutulur.
    char *prime_states;

    printf("Sieve of Eratosthenes algoritmas�n� kullanarak asal say�\nolu�turmak i�in bir n tamsay�s� giriniz : ");
    
    // Kullan�c�dan n tam say�s� istenir.
    scanf("%d", &n);
    
    // n de�erini bir azalt�l�r ��nk� 1 say�s� asal say� de�ildir.
    // n de�eri 10 girilmi� olacak olursa kontrol edilecek say�lar 2,3,4,5,6,7,8,9,10 olur.
    n-=1;
    
    // A�a��daki kod par�as� ile kullan�c�dan al�nan tam say�n�n bir eksi�i uzunlu�unda haf�zada yer ayr�l�r.
    prime_states = (char *) malloc ((n) * sizeof(char));

    // Bellekte yeterli alan olu�turulup olu�turulamad��� kontrol edilir.
    if(prime_states == NULL)
    {
        printf("Bellekte alan olu�turulamad�.");
        exit(0); // Exit from the program
    }

    // Dizideki t�m say�lar asal say� olarak i�aretlemek i�in a�a��daki d�ng� kullan�l�r.    
    for(i = 0; i < n; i++)
    {
	//1(true) de�eri say�n�n asal oldu�unu ifade eder.
        prime_states[i] = 1;
    }
    
     /* a^2 <= n kontrol�n� sa�larken i de�erinin 2 fazlas� kullan�l�r
     * ��nk� 0'�nc� indexde 2 de�erinin asal say� olup olmad���n� belirten boolean de�er tutulur.
     * Bu sebeple i de�erinin 2 fazlas� kullan�l�r.
     */
    for(i = 0; (i + 2)*(i + 2) <= n+1; i++)
    {
        if(prime_states[i] == 1) // 1 = true
        {
            for(j = (i + 2)*(i + 2); j <= n+1; j += i+2 )
            {
                prime_states[j-2] = 0; // 0 = false
            }
        }
    }
    // Ka� adet asal say� tespit edildi�i a�a��daki d�ng� ile belirlenir.
    prime_count = 0;
    for(i = 0; i < n; i++)
    {
        if(prime_states[i] == 1)
            prime_count++;
    }
    
    // A�a��daki kod par�as� ile asal say� adedi uzunlu�unda haf�zada yer ayr�l�r.
    primes = (int *) malloc (prime_count * sizeof(int));
    
    // Bellekte yeterli alan olu�turulup olu�turulamad��� kontrol edilir.
    if(primes == NULL)
    {
        printf("Bellekte alan olu�turulamad�.");
        exit(0); // Exit from the program
    }
    
    // Belirlenen asal say�lar yeni bir dizide a�a��daki d�ng� yard�m� ile tutulur.
    // j, asal say�lar�n tutuldu�u dizi i�in kullan�lacak indexdir.
    j = 0;
    for(i = 0; i < n; i++)
    {
        if(prime_states[i] == 1)
        {
            primes[j] = i + 2;
            j++;
        }
    }
    
    printf("-Program ��kt�s�-\n0-%d aras�ndaki asal say�lar: ", n+1);
    
    for(i = 0; i < prime_count; i++)
    {
    	// Her 10 asal say�da bir new line yapmak i�in a�a��daki if blo�u kullan�labilir.
        if(i % 10 == 0) 
            printf("\n");
        if(i == prime_count-1)
            printf("%5d ", primes[i]);
        else
            printf("%5d, ", primes[i]);
    }
    
    free(prime_states);
    free(primes);
    return 0;
}
