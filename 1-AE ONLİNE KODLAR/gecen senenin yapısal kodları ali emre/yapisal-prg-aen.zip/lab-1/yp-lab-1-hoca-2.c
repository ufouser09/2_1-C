#include <stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main()
{
    // n, m, i ve j de�i�kenleri d�ng�lerde kullan�lmak �zere tan�mlan�r.
    // pixel kullan�c�dan al�nan �ifrelenmi� karakterlerin de�erini tutamak �zere kullan�l�r.
    // textIndex de�i�keni ��z�mlenmi� kelimenin tutulaca�� dizide index olarak kullan�l�r.
    int n,m,i,j,pixel,textIndex=0;
    
    // text dizisi 1D bir dizidir. Pixel matrisinin i�inde gizlenen stringi tutmak �zere kullan�l�r.
    char * text;
    
    // �ifrelenmi� kelimenin pixel de�erlerini tutmak �zere kullan�l�r.
    int **theImage;
    
    // ��z�mlenecek MxM pixel matrisinin M de�eri kullan�c�dan istenir.
    printf("Enter Image Size: M \n");
    scanf("%d",&m);
    
    // text dizisi olu�turulur.
    text=(char *)(malloc)(sizeof(char));
    
    // theImage dizisi (2D) 2 boyutlu bir dizidir.
    // �ifrelenmi� pixelleri tutmak �zere kullan�l�r.
    // m say�s� kadar sat�r olu�turulur.
    theImage=(int**)(calloc)(m,sizeof(int*));
	
    for(i=0;i<m;i++)
    {
    	// Her bir sat�rda m say�s� kadar s�tun olu�turulur.
        theImage[i]=(int*)(calloc)(m,sizeof(int));
    }
    
    // �ifrelenmi� MxM pixel matrisi kullan�c�dan al�n�r.
    printf("Enter The Pixel Values from top-left to bottom-right\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("(%d, %d) =", i, j);
            scanf("%d",&pixel);
            theImage[i][j]=pixel;
        }
    }
    
    for (i=0;i<m;i++)
    {
        for(j=0;j<m;j++)
        {        	
            // text dizisini 1 eleman geni�letmek i�in kullan�l�r.
            text=(char*)(realloc)(text,sizeof(char));
            // pixel de�erinin ASCII codu kar��l��� elde edilir ve text dizisinin ilgili indexine atan�r.
            text[textIndex]=(char)theImage[i][j];
            textIndex++;
            
            /* Alternatif 
             * pixel de�eri s�f�ra e�it ise harf yok demektir ve a�a��daki if blo�u ile kontrol edilir.
            if(theImage[i][j] != 0)
	    {
            	// text dizisini 1 eleman geni�letmek i�in kullan�l�r.
		text=(char*)(realloc)(text,sizeof(char));
		// pixel de�erinin ASCII codu kar��l��� elde edilir ve text dizisinin ilgili indexine atan�r.
		text[textIndex]=(char)theImage[i][j];
		textIndex++;
	    }
	     */
        }
    }

    printf("The Text That Was Hidden Into The Image is: %s\n",text);

    free(theImage);
    free(text);
    
    return 0;
}
