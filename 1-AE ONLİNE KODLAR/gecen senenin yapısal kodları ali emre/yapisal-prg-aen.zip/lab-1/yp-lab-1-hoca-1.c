#include <stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main()
{
    // textSize de�i�keni kullan�c�n�n girece�i kelimenin uzunlupunu tutar.
    // i, j, m ve k de�i�kenleri d�ng�lerde kullan�lmak �zere tan�mlan�r.
    // pixel de�i�keni karakterlerin tam say� de�erini tutamk �zere kullan�l�r.
    int textSize,i,j,pixel,m,k=0;
    // text dizisi 1D bir dizidir. Kullan�c�dan al�nacak stringi tutmak �zere kullan�l�r.
    // junk de�i�keni new line ifedesini ��pe atmak i�in kullan�l�r.
    char * text,junk;
    // theImage dizisi (2D) 2 boyutlu bir dizidir.
    // kullan�c�dan al�nan kelimenin �ifrelenmi� pixellerini tutmak �zere kullan�l�r.
    int **theImage;
    
    printf("Enter The Lenght of Text To Encrypt\n");
    scanf("%d",&textSize);
    
    // text dizisi kullan�c�dan al�nan say� do�rultusunda olu�turulur.
    text=(char *)(malloc)(sizeof(char)*textSize);
    // theImage dizisi 1x1 boyutunda olu�turulur daha sonra boyutu de�i�tirilmek �zere.
    theImage=(int**)(calloc)(1,sizeof(int*));
    theImage[0]=(int*)(calloc)(1,sizeof(int));

    printf("Enter The Text\n");
    scanf("%c",&junk); //"\n" karakterini ��pe at�yoruz.
    scanf("%[^\n]",text);
    // Alternatif (scanf("%s",text);)
    
    // kelimenin mxm boyutunda bir dizide saklanmas� i�in minimum m say�s� a�a��daki gibi hesaplan�r.
    m=ceil(sqrt(textSize));

    // sat�r say�s�n�n g�ncellenmesi
    theImage=(int**)(calloc)(m,sizeof(int*));
    for(i=0; i< m; i++)
    {
        // sat�rdaki s�tun say�s�n�n g�ncellenmesi
	theImage[i]= (int*)(calloc)(m,sizeof(int));
    }
 
    for(i=0;i<m;i++)
    {        
        for(j=0;j<m;j++)
        {
            /* 5 harflik bir kelime 3x3 boyutunda bir dizide saklan�r.
             * �rne�in "TAHTA" kelimesini inceleyelim. T=1,A=2,H=3 olarak kodlayacak olal�m. Olu�acak dizi a�a��daki gibidir.
             * 1 2 3
             * 1 2 0
             * 0 0 0
             * g�r�ld��� gibi t�m harfler d�n��t�r�ld�kten sonra kalan pixellere s�f�r de�eri yaz�l�r.
             * burada k de�i�keni kelimenin tutuldu�u dizi i�in index'i tutar.
             * index kelime boyutunu a�t���nda ilgili pixele s�f�r de�erini atamak i�in a�a��daki if-else blo�u kullan�l�r.
	     */
            if(k < textSize)
	    {
		// karakterin tam say� de�erinin pixel de�i�kenine atanmas�.
		pixel=(int)text[k];
            	theImage[i][j]=pixel;
	    }
            else
                theImage[i][j]=0;
            k++;
        }
    }

    printf("The Image is: \n");
    
	// theImage matrisinin yazd�r�lmas�.
    for(i=0;i<m;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("%3d ",theImage[i][j]);
        }
        printf("\n");
    }

    free(theImage);
    free(text);
    
    return 0;
}
