#include <stdio.h>
#include <stdlib.h>

typedef struct node{
	int data;
	struct node *next;
}NODE;

NODE *head=NULL;
NODE *create_node();
void insert_at_begin(int d);
 void insert_at_end(int d);
void traverse();
int main(){
	int data;
	int i=0;
	
	while(i!=5){
		
		printf("Enter choice\n1-Insert begin\n2-Insert end\n 3-traverse\n 5-Exit "); 
		scanf("%d",&i);
		
		if(i==1){
			printf("Enter data"); scanf("%d",&data);
			insert_at_begin(data);
		}
		else if(i==2){
			printf("Enter data"); scanf("%d",&data);
			insert_at_end(data);
		}
		else if(i==3){
			traverse();
		}
		
	}	
}
 void insert_at_begin(int d){
 	NODE *tmp=create_node();
 	//tmp->data=d;
 	
 	if(head==NULL){
 		head=tmp;
 		head->next=NULL;
 		head->data=d; // instead of //tmp->data=d;
	 }
	 else{
	 	tmp->next=head;
	 	head=tmp;
	 	head->data=d; //inplace of //tmp->data=d;
	 }
 }
 
 void insert_at_end(int d){
 	NODE *n=create_node();
 	NODE *tmp;
 	n->data=d;
 	
 	if(head==NULL){
 		head=n;
 		head->next=NULL;
 		return;
	 }
	 else{
	 	tmp=head;
	 	while(tmp->next!=NULL){
	 		tmp = tmp->next;
		 }
		 tmp->next=n;
		 n->next=NULL;
	 }
	
 }
 void traverse(){
 	NODE *tmp;
 	tmp=head;
 	if(tmp==NULL){
 		printf("List is empty\n");
 		return;
	 }
	 printf("Elements in list are listed below\n");
	 while(tmp->next!=NULL){
	 	printf("[%d ->",tmp->data);
	 	tmp = tmp->next;
	 }
	 printf("%d ->]\n",tmp->data);
 }
 
 NODE *create_node(){	
 	return (NODE*) malloc(sizeof(NODE));;
 }
