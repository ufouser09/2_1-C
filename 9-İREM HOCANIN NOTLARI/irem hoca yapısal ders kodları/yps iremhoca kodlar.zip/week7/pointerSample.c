#include <stdio.h>
int main ()  {
    static int a[2][3]={ {-3, 14, 5} , {1, -10, 8} }; 
    static int *b[]={ a[0], a[1] };
    int *p=b[1],i;
    unsigned int j;
    char* str="irem";
    printf("1:%p 2:%p 3:%p 4:%c\n", str,&str,&str[0],*(&str));
    int dizi[3]={1,2,3};
	printf("1:%p 2:%p 3:%p 4:%d\n", dizi,&dizi,&dizi[0],*(&dizi));
    
    printf("*b[1] = %d\n", *b[1]); //1
    printf("*(++p) = %d\n", *(++p));//-10
    printf("*(*(a+1)+1) = %d\n",  *(*(a+1)+1) );//-10

    // yukaridaki ++p'y' geri alalim, ilk degeri olan b[1]'yi atayalım: 
    p=b[1];
    printf("*(--p-2) = %d\n",  *(--p-2) ); //-3

    for(i=0; i<2; i++) printf("a: %d \t", *a[i]); //-3 1
    printf("\n");

	printf("%u %d\n",10u-15,10u-15); //suffix: indicate the type of literal :Ll  Uu UL  43L gibi
	if ((10u-15)>0) //signed type is converted to the unsigned type
		printf("unsigned\n");
    return 0; 
}

