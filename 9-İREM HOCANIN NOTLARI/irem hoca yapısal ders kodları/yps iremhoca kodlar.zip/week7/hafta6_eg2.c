
#include <stdio.h>
int main ()  {
    static int a[2][3]={ {-3, 14, 5} , {1, -10, 8} };
    int i, j=1, k=2; 

    printf("*(a[j] +k) = %d\n", *(a[j] +k) );
    printf("(*(a+j))[k] = %d\n", (*(a+j))[k] );
    printf("*(*(a+j) + k) = %d\n", *(*(a+j) + k) );

    int ncol=3;
    printf("*(&a[0][0] + j*3 + k) = %d\n", *(&a[0][0] + j*ncol + k) );

    return 0; 
}

