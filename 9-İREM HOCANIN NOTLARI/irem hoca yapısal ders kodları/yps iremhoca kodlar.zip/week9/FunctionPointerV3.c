#include <stdio.h>
// Two simple functions
void fun1(int,int);
void fun2(int,int);
void (*wrapper(int,int))(int,int);
void wrapper2(int,int);
void (*wrapper3())();
void (*wrapper4(int,int))();


// wrapper4() receives two integers a and b, returns function*, function pointer's parameters are not defined
void (*wrapper4(int a,int b))()
{
	if (a>b)
		return fun1;
	else
		return fun2;
}

//void (*wrapper3())(int a,int b)  //this is also legal (int a,int b) is reduntant part
void (*wrapper3())()
{
		return fun1;
}

// wrapper4() receives two integers c and d, returns function*, 
//function pointer's parameters are defined as a and b but not used in wrapper also not recognized
void (*wrapper(int c,int d))(int a,int b)
{
	//printf("%d ",a);  //will not compiled
	if (c>d)
		return fun1;
	else
		return fun2;
}


// wrapper2() receives two integers as parameters
// and calls fun1() and fun2() functions
void wrapper2(int a,int b)
{
	if (a>b)		//the code detecting the optimum sorting algorithm
		fun1(a,b);
	else
		fun2(a,b);
}

int main()
{
	wrapper4(10,20)(5,8); //decides by using 10 and 20. Send 5 and 8 as parameters to the function pointer. fun2 executed
	(*wrapper4(10,20))(5,8);				//legal same as the one above
	wrapper(17,12)(10,20);	//decides by using 17 and 12. Send 10 and 20 as parameters to the function pointer. fun1 executed
	wrapper3()(10,20); //just pass 10 and 20 to fun1
	
	return 0;
}

void fun1(int a,int b)
{
	printf("Fun1:%d\n",a-b);  //Quick Sort 
	
}

void fun2(int a,int b)
{ 
	printf("Fun2:%d\n",b-a); //Merge Sort
}
