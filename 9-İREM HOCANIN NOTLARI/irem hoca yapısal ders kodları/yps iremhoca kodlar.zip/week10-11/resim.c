#include <stdio.h>
#include <stdlib.h>
typedef struct{
 unsigned char r,g,b,y; 
 }IMG; 
 
 IMG** create (unsigned int,unsigned int);
 void findGreyscale(IMG **,unsigned int, unsigned int);
 void findHistogram (IMG **,unsigned int, unsigned int, unsigned int*) ;
 unsigned int * findHistogramV2 (IMG ** ,unsigned int , unsigned int ) ;
 
 int main()
 {
 	IMG **resim;
 	unsigned int n,m,i,j;
	static unsigned int hist[256];
	//unsigned int* hist;
 	scanf("%d %d",&n,&m);
 	resim=create(n,m);
 	for (i=0;i<n;i++)
 		for (j=0;j<m;j++)
 			scanf("%d %d %d",&resim[i][j].r,&resim[i][j].g,&resim[i][j].b);
 	findGreyscale(resim,n,m);
	findHistogram (resim,n,m,hist);
	//hist=findHistogramV2 (resim,n,m);
	for (i=0;i<=255;i++)
		printf("%d ",hist[i]);
 	return 0; 	
 }


IMG** create(unsigned int row, unsigned int column)
{
	unsigned int i;
	IMG **matrix;
 	matrix=(IMG **) calloc (row,sizeof(IMG*));
	for (i=0;i<row;i++)
	{
		matrix[i]=(IMG*) calloc (column, sizeof(IMG));
	}
	return matrix;
}


void findGreyscale(IMG ** matrix,unsigned int row, unsigned int column) 
{
	unsigned int i,j;
 	for (i=0;i<row;i++)
 		for (j=0;j<column;j++)
 			matrix[i][j].y=(matrix[i][j].r+matrix[i][j].g+matrix[i][j].b)/3;
}


void findHistogram (IMG ** matrix,unsigned int row, unsigned int column, unsigned int* hist) 
{
	unsigned int i,j;
	for (i=0;i<row;i++)
 		for (j=0;j<column;j++)
 			hist[matrix[i][j].y]++;
}

unsigned int * findHistogramV2 (IMG ** matrix,unsigned int row, unsigned int column) 
{
	unsigned int i,j;
	static unsigned int hist[256];
	for (i=0;i<row;i++)
 		for (j=0;j<column;j++)
 			hist[matrix[i][j].y]++;
 	return hist;
}

