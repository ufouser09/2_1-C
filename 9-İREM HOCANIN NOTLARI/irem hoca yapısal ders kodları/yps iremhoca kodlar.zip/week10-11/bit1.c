#include <stdio.h>
struct init
{
	int num:1;
	unsigned short val:1;
};

int main()
{
	struct init iu={1,1};		//num field'inin var olan tek biti sign bit olarak kullanilir
	printf("%d %d\n",iu.num,iu.val);
}


