// atletlerin bilgileri bir structure yapisinda tutuluyor
// N atlet i�in dinanik olarak yer acalim ve bilgilerini alalim
#include<stdio.h>
#include<stdlib.h>
typedef struct
{
	char ad[15];
	int sure:4;
	union
	{
	   unsigned int puan;  		// 32 bit 
	   char odul[3];	 	 	// 8*3=24 bit
	} SKOR;
}ATLET ;

int main()
{
   int i,j,hizli,yavas,hizliy=0,yavasy=0,n,puan1=0,a;
   unsigned int l;
   char k;
   ATLET *dizi;
   printf("kac adet atlet girmek istiyorsunuz\n");
   scanf("%d",&n);
   // yer acalim
   dizi=(ATLET *) calloc(n,sizeof(ATLET));
   //atlet bilgilerini alalim
   for (i=0;i<n;i++)
  {
	   printf("%d.kisi icin ;\n",i+1);
	   printf("ad:");
	   scanf("%s",dizi[i].ad);
	   printf("sure:");
	   scanf("%d",&a);
	   dizi[i].sure=a;
	   printf("altin madalya sayisi:");
	   scanf("%d",&dizi[i].SKOR.odul[0]);
	   printf("gumus madalya sayisi:");
	   scanf("%d",&dizi[i].SKOR.odul[1]);
	   printf("bronz madalya sayisi:");
	   scanf("%d",&dizi[i].SKOR.odul[2]);
  }

  //en h�zli ve yava� atletleri bulalim. 
  hizli=dizi[0].sure;
  yavas=0;

  for (i=0;i<n;i++)
  {
  	if (dizi[i].sure>yavas)
    {
    	yavas=dizi[i].sure;
    	yavasy=i;
    }
    if (dizi[i].sure<hizli)
  	{
	    hizli=dizi[i].sure;
    	hizliy=i;
    }
    //odul sayilarindan yola cikarak puanlarini asagidaki katsayilar ile hesaplayalim
    puan1=(dizi[i].SKOR.odul[0]*10000)+(dizi[i].SKOR.odul[1]*5000)+(dizi[i].SKOR.odul[2]*1000);
    //odul sayilari yerine puanlarini tutalim
    dizi[i].SKOR.puan=puan1;	
  }
   printf("en hizli atlet:%d, puani:%d\n",hizliy,dizi[hizliy].SKOR.puan);
   printf("en yavas atlet:%d, puani:%d\n",yavasy,dizi[yavasy].SKOR.puan);
   return 0;
 }
