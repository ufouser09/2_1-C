
// C program to reverse a string using recursion 
# include <stdio.h> 
  
/* Function to print reverse of the passed string */
void reverse(char **ar,int i,int n) 
{ 
   if (i<n) 
   { 
       reverse(ar,i+1,n); 
       printf("%s", ar[i]); 
   } 
} 
  
/* Driver program to test above function */
int main() 
{ 
   char* a[] = {"yap�sal","programlama","dersindeyiz"}; 
   reverse(a,0,3); 
   return 0; 
} 
