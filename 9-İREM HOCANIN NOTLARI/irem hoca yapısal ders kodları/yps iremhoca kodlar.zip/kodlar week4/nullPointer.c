#include <stdio.h>
int main()
{
	int *i,*j;
	int *ii=0,*jj=0;	//int *ii=NULL, *jj=NULL;
	if (i==j)
		printf("i and j are same by chance\n");
	if (ii==jj)
		printf("ii and jj are always same");
	return 0;	
}
