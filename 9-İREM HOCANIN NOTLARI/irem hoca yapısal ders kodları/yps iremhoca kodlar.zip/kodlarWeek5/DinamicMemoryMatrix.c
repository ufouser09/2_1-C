#include <stdio.h>
#include <stdlib.h>
int main()
{		
	int row,column,i,j;
	float **matrix,*p;
	printf("1-9 araliginda olmak uzere satir ve sutun sayisini veriniz\n");
	scanf("%d %d",&row,&column);
	matrix=(float **) calloc (row,sizeof(float*));
	printf("adress of matrix:%p adress in matrix:%p\n",&matrix,matrix);
	for (i=0;i<row;i++)
	{
		matrix[i]=(float*) calloc (column, sizeof(float));
		printf("adress of matrix[%d]:%p adress in matrix[%d]:%p\n",i,&matrix[i],i,matrix[i]);
	}
	for(i=0;i<row;i++)
		for(j=0;j<column;j++)
			matrix[i][j]=i+(float)j/10;
			
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
			printf("%1.1f  ",matrix[i][j]);
		printf("\n");
	}
	
	printf("adresses of the cells\n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<column;j++)
			printf("%p  ",&matrix[i][j]);
		printf("\n");
	}
	// ILLEGAL USAGE
	/*p=(float *)*matrix;
    for (i=0;i<row*column;i++)
	printf("adre:%p pvalue:%f\n",p+i,*(p+i));*/
	
	for (i=0;i<row;i++)
	{
		free(matrix[i]);
	}
	free(matrix);
	return 0;		
}	
